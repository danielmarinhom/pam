﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RpgAPI.Migrations
{
    /// <inheritdoc />
    public partial class Inicial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Username",
                table: "TB_USUARIOS",
                type: "Varchar(200)",
                maxLength: 200,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Perfil",
                table: "TB_USUARIOS",
                type: "Varchar(200)",
                maxLength: 200,
                nullable: true,
                defaultValue: "Jogador",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true,
                oldDefaultValue: "Jogador");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "TB_USUARIOS",
                type: "Varchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nome",
                table: "TB_PERSONAGENS",
                type: "Varchar(200)",
                maxLength: 200,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Nome",
                table: "TB_HABILIDADES",
                type: "Varchar(200)",
                maxLength: 200,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Nome",
                table: "TB_ARMAS",
                type: "Varchar(200)",
                maxLength: 200,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 5, "Espada de Madeira" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 10, "Espada de Ferro" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 15, "Espada de Diamante" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 20, "Cajado de Fogo" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 25, "Cajado de Gelo" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 35, "Cajado de Relâmpago" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 999, "Lança" });

            migrationBuilder.UpdateData(
                table: "TB_USUARIOS",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "DataAcesso", "Email", "PasswordHash", "PasswordSalt" },
                values: new object[] { new DateTime(2025, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "seuEmail@example.com", new byte[] { 72, 0, 97, 212, 114, 30, 217, 31, 57, 87, 38, 79, 189, 238, 240, 98, 35, 83, 167, 64, 220, 136, 12, 133, 115, 19, 156, 240, 155, 164, 126, 181, 51, 251, 51, 86, 223, 157, 146, 150, 83, 114, 32, 135, 109, 39, 76, 134, 45, 88, 123, 150, 161, 78, 86, 201, 90, 146, 49, 116, 149, 120, 32, 149 }, new byte[] { 53, 155, 186, 30, 188, 212, 250, 87, 113, 8, 161, 254, 83, 143, 103, 67, 46, 80, 115, 238, 134, 48, 163, 203, 123, 100, 212, 5, 195, 104, 7, 213, 91, 64, 124, 239, 190, 202, 221, 126, 114, 186, 79, 145, 167, 14, 186, 8, 224, 89, 19, 25, 175, 143, 58, 2, 49, 178, 172, 4, 126, 68, 247, 147, 113, 192, 127, 20, 8, 80, 35, 57, 209, 128, 212, 233, 122, 127, 245, 76, 185, 125, 4, 3, 70, 253, 13, 36, 4, 64, 79, 170, 86, 163, 115, 109, 82, 197, 100, 192, 51, 165, 218, 86, 23, 106, 45, 47, 22, 163, 230, 222, 202, 86, 235, 121, 13, 8, 235, 228, 150, 95, 155, 125, 119, 99, 143, 185 } });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Username",
                table: "TB_USUARIOS",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "Varchar(200)",
                oldMaxLength: 200);

            migrationBuilder.AlterColumn<string>(
                name: "Perfil",
                table: "TB_USUARIOS",
                type: "nvarchar(max)",
                nullable: true,
                defaultValue: "Jogador",
                oldClrType: typeof(string),
                oldType: "Varchar(200)",
                oldMaxLength: 200,
                oldNullable: true,
                oldDefaultValue: "Jogador");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "TB_USUARIOS",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "Varchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nome",
                table: "TB_PERSONAGENS",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "Varchar(200)",
                oldMaxLength: 200);

            migrationBuilder.AlterColumn<string>(
                name: "Nome",
                table: "TB_HABILIDADES",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "Varchar(200)",
                oldMaxLength: 200);

            migrationBuilder.AlterColumn<string>(
                name: "Nome",
                table: "TB_ARMAS",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "Varchar(200)",
                oldMaxLength: 200);

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 35, "Arco e Flecha" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 33, "Espada" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 31, "Machado" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 30, "Punho" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 34, "Chicote" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 33, "Foice" });

            migrationBuilder.UpdateData(
                table: "TB_ARMAS",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "Dano", "Nome" },
                values: new object[] { 32, "Cajado" });

            migrationBuilder.UpdateData(
                table: "TB_USUARIOS",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "DataAcesso", "Email", "PasswordHash", "PasswordSalt" },
                values: new object[] { null, "seuEmail@gmail.com", new byte[] { 225, 144, 85, 170, 173, 236, 61, 117, 63, 146, 93, 165, 56, 208, 70, 202, 177, 163, 92, 124, 132, 71, 47, 135, 71, 214, 66, 118, 146, 160, 27, 214, 86, 87, 199, 49, 9, 231, 144, 116, 217, 122, 7, 222, 84, 187, 14, 73, 232, 176, 106, 102, 79, 180, 246, 0, 251, 66, 63, 131, 63, 169, 40, 124 }, new byte[] { 10, 85, 187, 164, 162, 245, 9, 178, 8, 132, 189, 189, 85, 27, 53, 170, 122, 171, 121, 160, 246, 111, 192, 132, 239, 228, 90, 33, 191, 162, 188, 149, 160, 248, 69, 140, 172, 102, 198, 23, 252, 159, 124, 91, 15, 43, 14, 202, 55, 55, 239, 161, 189, 89, 85, 225, 233, 71, 74, 243, 232, 30, 90, 60, 121, 157, 60, 158, 36, 226, 141, 113, 146, 4, 104, 247, 104, 103, 101, 229, 25, 26, 164, 112, 251, 204, 174, 158, 93, 126, 126, 54, 137, 28, 67, 43, 87, 74, 107, 75, 238, 5, 145, 118, 94, 196, 143, 210, 77, 20, 131, 110, 48, 122, 47, 98, 220, 191, 255, 193, 251, 197, 204, 189, 107, 97, 234, 40 } });
        }
    }
}
